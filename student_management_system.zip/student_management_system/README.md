# Student Management System

Python (Flask) + SQL (SQLite) + CSS.

## Features
- Add, edit, delete students
- Search by name / roll number / email, filter by course, sort by name / GPA / year
- Summary stats (SQL aggregates), validation, duplicate detection

## Run
```bash
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000. The database (`students.db`) is created from `schema.sql` on first run.

## Structure
```
app.py          Flask routes and database logic
schema.sql      Tables, indexes, sample data
templates/      base.html, index.html, form.html
static/style.css
```
