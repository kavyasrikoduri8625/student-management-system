"""Student Management System - Flask + SQLite."""
import os
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash, g

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "students.db")

app = Flask(__name__)
app.secret_key = "change-this-secret-key"


# ---------- Database helpers ----------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        with open(os.path.join(BASE_DIR, "schema.sql"), encoding="utf-8") as f:
            conn.executescript(f.read())


def read_form():
    f = request.form
    gpa = f.get("gpa", "").strip()
    return {
        "roll_no": f.get("roll_no", "").strip(),
        "full_name": f.get("full_name", "").strip(),
        "email": f.get("email", "").strip(),
        "phone": f.get("phone", "").strip(),
        "course_id": f.get("course_id") or None,
        "year": int(f.get("year") or 1),
        "gpa": float(gpa) if gpa else None,
    }


def validate(data):
    if not data["roll_no"] or not data["full_name"] or not data["email"]:
        return "Roll number, name and email are required."
    if "@" not in data["email"]:
        return "Enter a valid email address."
    if data["gpa"] is not None and not 0 <= data["gpa"] <= 10:
        return "GPA must be between 0 and 10."
    return None


# ---------- Routes ----------
@app.route("/")
def index():
    q = request.args.get("q", "").strip()
    course = request.args.get("course", "")
    sort = request.args.get("sort", "name")
    order = {"name": "s.full_name", "gpa": "s.gpa DESC", "year": "s.year"}.get(sort, "s.full_name")

    sql = """
        SELECT s.*, c.name AS course_name, c.code AS course_code
        FROM students s LEFT JOIN courses c ON c.id = s.course_id
        WHERE (s.full_name LIKE :q OR s.roll_no LIKE :q OR s.email LIKE :q)
    """
    params = {"q": f"%{q}%"}
    if course:
        sql += " AND s.course_id = :course"
        params["course"] = course
    sql += f" ORDER BY {order}"

    db = get_db()
    students = db.execute(sql, params).fetchall()
    courses = db.execute("SELECT * FROM courses ORDER BY name").fetchall()
    stats = db.execute(
        "SELECT COUNT(*) AS total, ROUND(AVG(gpa), 2) AS avg_gpa, "
        "COUNT(DISTINCT course_id) AS courses FROM students"
    ).fetchone()
    return render_template("index.html", students=students, courses=courses,
                           stats=stats, q=q, course=course, sort=sort)


@app.route("/add", methods=["GET", "POST"])
def add_student():
    db = get_db()
    courses = db.execute("SELECT * FROM courses ORDER BY name").fetchall()
    if request.method == "POST":
        data = read_form()
        error = validate(data)
        if error:
            flash(error, "error")
            return render_template("form.html", courses=courses, student=data, mode="add")
        try:
            db.execute(
                "INSERT INTO students (roll_no, full_name, email, phone, course_id, year, gpa) "
                "VALUES (:roll_no, :full_name, :email, :phone, :course_id, :year, :gpa)", data)
            db.commit()
        except sqlite3.IntegrityError:
            flash("That roll number or email is already registered.", "error")
            return render_template("form.html", courses=courses, student=data, mode="add")
        flash(f"{data['full_name']} was added.", "success")
        return redirect(url_for("index"))
    return render_template("form.html", courses=courses, student={}, mode="add")


@app.route("/edit/<int:student_id>", methods=["GET", "POST"])
def edit_student(student_id):
    db = get_db()
    courses = db.execute("SELECT * FROM courses ORDER BY name").fetchall()
    student = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
    if student is None:
        flash("Student not found.", "error")
        return redirect(url_for("index"))
    if request.method == "POST":
        data = read_form()
        data["id"] = student_id
        error = validate(data)
        if error:
            flash(error, "error")
            return render_template("form.html", courses=courses, student=data, mode="edit")
        try:
            db.execute(
                "UPDATE students SET roll_no=:roll_no, full_name=:full_name, email=:email, "
                "phone=:phone, course_id=:course_id, year=:year, gpa=:gpa WHERE id=:id", data)
            db.commit()
        except sqlite3.IntegrityError:
            flash("That roll number or email is already registered.", "error")
            return render_template("form.html", courses=courses, student=data, mode="edit")
        flash("Changes saved.", "success")
        return redirect(url_for("index"))
    return render_template("form.html", courses=courses, student=student, mode="edit")


@app.route("/delete/<int:student_id>", methods=["POST"])
def delete_student(student_id):
    db = get_db()
    db.execute("DELETE FROM students WHERE id = ?", (student_id,))
    db.commit()
    flash("Student deleted.", "success")
    return redirect(url_for("index"))


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
