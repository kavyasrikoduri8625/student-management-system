-- Student Management System schema (SQLite)
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS courses (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    code   TEXT NOT NULL UNIQUE,
    name   TEXT NOT NULL,
    credits INTEGER NOT NULL DEFAULT 3 CHECK (credits BETWEEN 1 AND 6)
);

CREATE TABLE IF NOT EXISTS students (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    roll_no     TEXT NOT NULL UNIQUE,
    full_name   TEXT NOT NULL,
    email       TEXT NOT NULL UNIQUE,
    phone       TEXT,
    course_id   INTEGER REFERENCES courses(id) ON DELETE SET NULL,
    year        INTEGER NOT NULL DEFAULT 1 CHECK (year BETWEEN 1 AND 6),
    gpa         REAL CHECK (gpa IS NULL OR (gpa >= 0 AND gpa <= 10)),
    enrolled_on DATE NOT NULL DEFAULT (DATE('now'))
);

CREATE INDEX IF NOT EXISTS idx_students_name   ON students(full_name);
CREATE INDEX IF NOT EXISTS idx_students_course ON students(course_id);

-- Sample data (only inserted when tables are empty)
INSERT OR IGNORE INTO courses (code, name, credits) VALUES
 ('CSE', 'Computer Science', 4),
 ('ECE', 'Electronics & Communication', 4),
 ('MEC', 'Mechanical Engineering', 4),
 ('BBA', 'Business Administration', 3);

INSERT OR IGNORE INTO students (roll_no, full_name, email, phone, course_id, year, gpa) VALUES
 ('S1001', 'Ananya Reddy',  'ananya@example.com', '9876500001', 1, 2, 8.7),
 ('S1002', 'Rahul Verma',   'rahul@example.com',  '9876500002', 2, 3, 7.9),
 ('S1003', 'Sneha Iyer',    'sneha@example.com',  '9876500003', 1, 1, 9.1),
 ('S1004', 'Karthik Rao',   'karthik@example.com','9876500004', 3, 4, 6.8);
